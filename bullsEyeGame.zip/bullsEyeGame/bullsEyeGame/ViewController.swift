//
//  ViewController.swift
//  bullsEyeGame
//
//  Created by Adnan Brohi on 10/11/2021.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var targetValue: UILabel!
    @IBOutlet var roundLabel: UILabel!
    @IBOutlet var slider: UISlider!
    @IBOutlet var scoreLabel: UILabel!
    
    var currVal: Int = 0
    var targVal: Int = 0
    var round: Int = 0
    var score: Int = 0
    //var slider: Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
        //rendGen()
        
//        let thumbnainormalimage = UIImage(named: "buttonLight")!
//        slider.setThumbImage(thumbnainormalimage, for: .normal)
//
//        let thumbnailhighimage = UIImage(named: "sliderThumb")!
//        slider.setThumbImage(thumbnailhighimage, for: .highlighted)
        
        //uiimageedgeinsets : expands of shirink the value
//        let insets = UIEdgeInsets (top: 0, left: 14, bottom: 0, right: 14)
//
//        let trackleft = UIImage(named: "sliderTrackLeft")
//        let leftTrackResizeable = trackleft?.resizableImage(withCapInsets: insets, slider.setMaximumTrackImage(leftTrackResizeable, for: .normal))
//
//        let trackRight = UIImage(named: "slideTrackRight")
//        let rightTrackResizeable = trackRight?.resizableImage(withCapInsets: insets slider.setMaximumTrackImage(rightTrackResizeable, for: .normal)
        
        startNewRound()
     }
    
    func startNewRound() {
        
        round += 1
        targVal = Int.random(in: 1...100)
        currVal = 50
        slider.value = Float(currVal)
        
        updateLabel()
       
        // targetValue.text = String(targVal)
       // currVal = 50
       }
    
    func updateLabel(){
        targetValue.text = String(targVal)
        scoreLabel.text = String(score)
        roundLabel.text = String(round)
    }
    
    func startNewGame(){
        round = 0
        score = 0
        startNewRound()
        
        let transition = CATransition()
        transition.type = CATransitionType.fade
        transition.duration = 1
        transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
        view.layer.add(transition, forKey: nil)
    }
    
    @IBAction func startOver(_ sender: Any) {
        startNewGame()
    }
    
        @IBAction func HitMe() {
        
        var title = "hello world"
        let difference = abs(targVal - currVal)
        var points = 100 - difference
        score += points
        
        if difference == 0 {
            title  = "Perfect"
            points += 100
        }
        else if difference < 5 {
            title = "you almost had it"
            if difference == 1 {
                points += 50
            }
        }
        else if difference < 10 {
            title = "pretty good"
        }
        else {
            title = "not even close"
        }
        let alert = UIAlertController(title: title, message: "points:  \(points)" , preferredStyle: .alert)
        let action = UIAlertAction (title: "OK", style: .default, handler: {_ in self.startNewRound()})
        let action2 = UIAlertAction (title: "Cencel", style: .destructive, handler: nil)
        alert.addAction(action)
        alert.addAction(action2)
        present(alert, animated: true, completion: nil)
       
    }
    @IBAction func Slider(_slider: UISlider) {
        currVal = lroundf(_slider.value)
    }
}

